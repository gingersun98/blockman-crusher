
World.Timer(10, function()
    --local guiMgr = GUIManager:Instance()
    UI:openWindow("seleceHeroWnd")
end)
require "script_client.rankMgr"









