Entity.addValueDef("score", 0, true, true, true)
Entity.addValueDef("power", 0, true, true, true)     --Data saves the player's power value
Entity.addValueDef("timeIndex", 0, true, true, true) --Time index, use it to sort the rank of power values when they are equal